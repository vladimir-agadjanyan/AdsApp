<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
            RoleSeeder::class,
            AdminUserSeeder::class,

            AdvertisingTypeSeeder::class,
            ObjectStatusSeeder::class,
            PhotoReportStatusSeeder::class,

            RegionSeeder::class,
            CitySeeder::class,

            CounterpartySeeder::class,
            ContractSeeder::class,
            ContractAddendumSeeder::class,

            AdvertisingObjectSeeder::class,

        ]);
    }
}
